﻿using System;

namespace SearchFight.Utilities
{
    public class SearchException : Exception
    {
        public readonly string Language;
        public readonly string Runner;

        public SearchException(string language, string runner, string message, Exception innerException)
            : base(message, innerException)
        {
            Language = language;
            Runner = runner;
        }

        public SearchException(string language, string runner, string message)
            : this(language, runner, message, null) { }
    }


}
