﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SearchFightTests
{
    [TestClass]
    public class ProgramTest
    {
        [TestMethod]
        public void Main_Return()
        {
            //SearchFight.Program oProgram = new SearchFight.Program();

            //oProgram.

            //Program.

            //Program.

            //program

        }
    }
}
