﻿using SearchFight.Utilities;
using System;
using System.ComponentModel;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SearchFight.Services
{
    [XmlInclude(typeof(HttpTextClient))]
    public abstract class TextClient
    {
        public static readonly TextClient Default = new HttpTextClient();

        public abstract Task<string> GetResponseText(Uri uri, StringDictionary headers);
    }

    public class HttpTextClient : TextClient{
        private const long DefaultTimeout = 30000;

        [XmlAttribute]
        [DefaultValue(DefaultTimeout)]
        public long Timeout { get; set; }

        public override async Task<string> GetResponseText(Uri uri, StringDictionary headers)
        {
            using (HttpClient client = new HttpClient(new HttpClientHandler() { AutomaticDecompression = System.Net.DecompressionMethods.Deflate | System.Net.DecompressionMethods.GZip }))
            {
                if (Timeout > 0)
                    client.Timeout = TimeSpan.FromMilliseconds(Timeout);
                else
                    client.Timeout = TimeSpan.FromMilliseconds(DefaultTimeout);

                if (headers != null){
                    foreach (var header in headers)
                        client.DefaultRequestHeaders.Add(header.Key, header.Value);
                }

                try{
                    //var httpClient = new HttpClient();
                    //HttpContent content = new StringContent(JsonConvert.SerializeObject(toPost), System.Text.Encoding.UTF8,WebConstants.ContentTypeJson);
                    //var response = await httpClient.PostAsync(new Uri(uri.AbsoluteUri), content, ct);
                    //var json = JsonConvert.SerializeObject(data);
                    //var content = new StringContent(  , System.Text.Encoding.UTF8, "application/json");
                    //HttpResponseMessage response = null;
                    //response = await client.PostAsync(uri

                    return await client.GetStringAsync(uri.AbsoluteUri);
                }
                catch (HttpRequestException ex){
                    throw new WebRequestException(ex.Message, ex);
                }
                catch (TaskCanceledException ex){
                    throw new WebRequestException("The request timed out.", ex);
                }
            }
        }
    }
}