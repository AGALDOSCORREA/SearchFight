﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SearchFight.Business
{
    public class Configuration
    {
        [XmlArrayItem("SearchRunner")]
        public List<SerializableSearchRunner> SearchRunners { get; set; }
    }
}
